import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VerdeComponent } from './verde.component';



@NgModule({
  declarations: [
    VerdeComponent
  ],
  imports: [
    CommonModule
  ]
})
export class VerdeModule { }
