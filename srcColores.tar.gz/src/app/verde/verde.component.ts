import { Component } from '@angular/core';

@Component({
  selector: 'app-verde',
  templateUrl: './verde.component.html',
  styleUrls: ['./verde.component.css']
})
export class VerdeComponent {

}
