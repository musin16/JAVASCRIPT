import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AzulComponent } from './azul/azul.component';
import { VerdeComponent } from './verde/verde.component';
const routes: Routes = [
  {path:"",
   component: AzulComponent,
   children:[{path:"",component:AzulComponent}]}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
