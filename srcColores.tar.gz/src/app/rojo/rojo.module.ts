import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RojoComponent } from './rojo.component';



@NgModule({
  declarations: [
    RojoComponent
  ],
  imports: [
    CommonModule
  ]
})
export class RojoModule { }
