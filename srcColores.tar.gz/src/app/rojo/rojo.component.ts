import { Component } from '@angular/core';

@Component({
  selector: 'app-rojo',
  templateUrl: './rojo.component.html',
  styleUrls: ['./rojo.component.css']
})
export class RojoComponent {

}
