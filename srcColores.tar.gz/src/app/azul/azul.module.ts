import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AzulComponent } from './azul.component';



@NgModule({
  declarations: [
    AzulComponent
  ],
  imports: [
    CommonModule
  ]
})
export class AzulModule { }
